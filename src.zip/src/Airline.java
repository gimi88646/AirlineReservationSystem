import javax.xml.crypto.Data;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Airline {

     Flight[] calender; // this will contain all the flights that are to takeoff within 30 days
//     ArrayList<User> users;
     User user=null;
     Admin admin =null;
     //agar me person ke hisab se se reference deta hu tou mere pos sirf wo method or attribute hongy jo person me hain

     //User user =null
     // Admin admin = null ... //agar me login karaty waqt inme assign krdu .. or logout krty waqt isme se dobara null krdu..
//     ArrayList<Admin> admins;
//     Admin admin;

     Connection connection;
     Statement statement;
     Airline(){
          try {
               connection = DriverManager.getConnection("jdbc:sqlite:AirlineDatabase.db");
               statement = connection.createStatement();
          }
          catch (SQLException se) {
               System.out.println("Something went wrong: " + se.getMessage());
          }
     }

     //jab airline blikul naye siry se banegi tou lamzi he ke me 30 days ki flights ek sath initiate krdu
     void login(String username, String password){
//          String query = "SELECT username,password WHERE username=''"
          try {
               statement.execute("CREATE TABLE IF NOT EXISTS Users(username TEXT,password TEXT,fullName TEXT,cnic TEXT,contact TEXT,address TEXT,email TEXT,gender TEXT,dateOfBirth TEXT,whenAccountCreated TEXT,userType TEXT)");
               statement.execute("SELECT username,userType FROM Users WHERE username='" + username + "' AND password='"+password+"'");
               ResultSet resultSet = statement.getResultSet();
               if (resultSet.next() ){
                   //call users sign method.. in that sign in take the attributes from database and reassign the user object
                    // according to the in database
//                    if userType == 'regular'
                    String userType = resultSet.getString("userType");
                    if (userType.equals("regular")){
                         user= new User(resultSet.getString("username"));
                    }
                    else if(userType.equals("admin")){
                         admin = new Admin(resultSet.getString("username"));
                    }

               }else {
                    System.out.println("User Not Found, make sure you've entered right ID and password");
               }

          } catch (SQLException queryFailed) {
               System.out.println("Something went wrong: "+ queryFailed.getMessage());
          }
     }
     void signUp(String username, String password,String fullName,String cnic,String contact,String address,String email,String gender,String dateOfBirth){
          //in sign up we will receive information from parameters and that information will then be stored in sql..
          //or and with that username and password information we will also execute users login method from this method..

          try {
               statement.execute("CREATE TABLE IF NOT EXISTS Users(username TEXT,password TEXT,fullName TEXT,cnic TEXT,contact TEXT,address TEXT,email TEXT,gender TEXT,dateOfBirth TEXT,whenAccountCreated TEXT,accountType TEXT)");
               statement.execute("INSERT INTO Accounts VALUES(" +
                       username+","+password+","+fullName+","+cnic+","+contact+","+address+","+email+","+gender+","+dateOfBirth+"NOW()"+"regular"+
                       ")");
               login(username,password);
          } catch (SQLException throwables) {
               throwables.printStackTrace();
          }

     }

     private boolean doesUserExist(String username,String password){

          try {
               statement.execute("SELECT username,password " + "FROM Accounts " +
                       "WHERE username='" + username + "' AND password='"+password+"'");
               ResultSet resultSet = statement.getResultSet();

          } catch (SQLException throwables) {
               throwables.printStackTrace();
          }
          return true;

     }
     ResultSet getFlights(Date date, String to, String from,int numberOfPassengers) {
//                       "Date = '"+ date + " AND "+
          //should this return arraylist of carrier objects
          // to make things less complex i better change the case to capitalizedCase of to and From,
          // or should i just leave it as it is, since we have to show the results that stored in flights table,
          // that means we must show the user the to from that lie in our domain, the user shouldn't manually input to-from
          // if not can split the string into first-letter part and other-than-first-letter part,
          // then perform firstLetter.uppercase() and otherThanFirstLetter.lowerCase and concatenate the string
          // this avoids case mismatching
          try {
               Date date1 = new Date();
               SimpleDateFormat DateFor = new SimpleDateFormat("MM/dd/yyyy");
               String stringDate = DateFor.format(date1);
               System.out.println( "date = "+date1);
//               statement.execute("SELECT * FROM Flights WHERE " +
//                       "travelTo = '" + to + " AND "+
//                       "travelFrom = '"+ from +
//                       "';" );
               statement.execute("select * from Flights where travelTo='karachi' and travelFrom='Lahore';");
               return statement.getResultSet();
          }
          catch (SQLException ex){
               System.out.println("something went wrong: "+ex.getMessage());
               return null;
          }
     }
}
