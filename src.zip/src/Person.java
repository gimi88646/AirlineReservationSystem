import java.math.BigInteger;

//this class is to be extended by User class and Admin class
public abstract class Person {
    boolean isSignedIn=false;
    String name;
    String username;


    Person(String username){
        this.name = name;
        this.username = username;
    }
    //should logout be a method?
    //if found it reassign the attributes of User Object and provide extra functionality
    // extra functionality  = history , view bookings, cancel bookings.
    void login(){
        //shal i recreate connections and statement object in order to execute login method
        isSignedIn = true;
    }

    void logOut() {
        isSignedIn = false;
        name = null;
        username = null;
    }
}
