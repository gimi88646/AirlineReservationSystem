import java.util.ArrayList;
import java.util.Date;

public class Flight {
    //Flight is all the number of carriers that are to takeoff for a day
    Date date;
    ArrayList<Carrier> carriers;

//    bahr se koi alag kism ka from to nahi aega hamare system me ho available hoga hum wohii show karaengy
//    only admin can add routes .. "A B" is a route from Source A to Destination B
    ArrayList<String> routes;

}
