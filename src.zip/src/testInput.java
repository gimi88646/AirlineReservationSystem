import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class testInput {
    public static void main(String[] args) {
        User user=new User("gimi");
        System.out.println("user is null:" +user==null);
        date();
        Scanner inp = new Scanner(System.in);
//        String s = inp.nextLine();
//        String a = inp.next();
//        System.out.println(s);
//        System.out.println(a);
        Date date1 = new Date();
        System.out.print("Enter date: ");
        String datein = inp.next();
        SimpleDateFormat DateFor = new SimpleDateFormat("MM/dd/yyyy");
        String stringDate = DateFor.format(datein);
        System.out.println( "date = "+datein);
        System.out.println("date after processing" + stringDate);

    }
    static void date(){
        Date date = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String strDate = dateFormat.format(date);
        System.out.println("Converted String: " + strDate);  }
}
