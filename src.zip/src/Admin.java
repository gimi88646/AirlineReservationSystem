public class Admin extends Person {
    Admin(String username){
        super(username);
    }
    // implementation of methods that are displayed in driver class
}
