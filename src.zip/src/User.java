public class User extends Person {

    // this attribute will be useful in Airline class because we will be able to check if user is a member
    // if is a member the program will provide the user extra functionality
    // extra functionality  = history , view bookings, cancel bookings.

    private boolean isSignedIn = false;

    //the user object is created when the program starts with default values (Anonymous)
    //if user wants to sign in. login method gets called
    User(){
        super("Anonymous");
    }

    //in user class there also should be some history so the user can see his previous history
    User(String username){
        super(username);
    }

    //if found it reassign the attributes of User Object and provide extra functionality
    // extra functionality  = history , view bookings, cancel bookings.
    void login(String username){
        //shal i recreate connections and statement object in order to execute login method
        isSignedIn = true;
    }

    public boolean getSignedStatus(){return isSignedIn;}
    void logOut() {
        isSignedIn = false;
    }

    public void book(){
        // when booking
    }
    public void viewBookings(){}
    public void cancelBooking(){}
    public void viewHistory(){}

}
