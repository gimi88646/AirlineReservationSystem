public class InputOutOfBound extends Exception{
    InputOutOfBound(String s){
        super(s);
    }
}
