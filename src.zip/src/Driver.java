import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.sql.ResultSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Driver {
    public static Scanner input= new Scanner(System.in);
    static Airline airline;

    public static void main(String[] args) {
        // see flights
        // login
        int choice;
        airline = new Airline();
//        String c =inputCnic();

        do {
            try{

                if(airline.user!=null){
                    //how should i change the options if the user has performed sign in
                    //when user signs in and he is a regular user he should be able to see following options

                    System.out.println(
                            "1. See Flights" +
                            "2. View Bookings" +
                            "3. Cancel Booking" +
                            "4. View History" +
                            "5. Log out" +
                            "6. Exit"
                    );
                    choice = input.nextInt();
                    if(choice>6 || choice <1) throw  new InputOutOfBound("Please make sure you made a right selection.");
                    switch (choice){
                        case 1:{
                            // see flights
                            // after the flights are displayed there has to be option for booking
                            // that booking actually invokes airline.user.book()
                            seeFlights();
                        }
                        case 2:{
                            //view Bookings
                            //the user should be able to see his bookings(this query will use username and date>=today )..
                            // this part should display the user of bookings of today and days forward
                            // for this the date of the system should be taken
                            // there should be query that compares the dates in sql with the current time and returns resultSet
                            // containing elements greater than or equals to the date of the system
                        }
                        case 3:{
                            // Cancel Booking
                            // this method should be implemented in user class, in user gets to to choose among his bookings and cancel that booking
                            // airline.user.cancelBooking() gets invoked
                        }
                        case 4:{
                            // view History
                            // the method should be in user class class.. and calling of method should be like airline.user.viewHistory
                            // the user gets to see the bookings...bookedBy "username" and date<now
                            // airline.user.viewHistory
                        }
                        case 5:{
                            //logout
                            airline.user=null;
                            break;
                        }
                        case 6:{
                            System.exit(0);
                        }
                    }
                }
                else if(airline.admin!=null)  {
                    //if the user is an admin he should be able to following options
                    System.out.println(
                            "1. Add a route" +
                            "2. Cancel a route" +
                            "3. Cancel a flight " +
                            "4. Log Out" +
                            "5. Exit"
                    );
                    choice = input.nextInt();
                    if (choice>5 || choice <1) throw new InputOutOfBound("Make sure your input is correct");
                    switch (choice){
                        case 1:{
                            // add a route
                            // the admin is supposed to enter a new flight and information relevant to the fight..
                            // and that information is inserted into the flights table in database
                            break;
                        }
                        case 2:{
                            //cancel a route
                            // the admin is supposed to cancel a route by making a selection amonn the flights available in flights table
                            break;
                        }
                        case 3: {
                            //cancel a flight
                            // the admin is supposed to enter a date and to-from , and on that specific date all the bookings of a to-from gets cancelled
                            break;
                        }
                        case 4: {
                            //log out
                            //when the admin logs out. the admin attribute in airline is assigned to null again
                            airline.admin=null;
                            break;
                        }
                        case 5: {
                            System.out.println("Buh byeee");
                            System.exit(0);
                        }
                    }
                }
                //once the program starts the neither admin nor user is signed in.. and he gets to see following options
                //if !airline.user.isSigned ..if user is null that means it not yet signed in..
                else{
                    System.out.print(
                            "1. See flights\n" +
                            "2. Log in\n" +
                            "3. Sign up\n" +
                            "4. Exit\n\n" +
                            "Please choose any of the above: "
                    );
                    choice=input.nextInt();
                    if (choice>4 || choice <1) throw new InputOutOfBound("Make sure your input is correct");
                    switch (choice){

                        // all the flight operations gets displayed
                        case 1: {
                            seeFlights();
                            break;
                        }

                        //login module
                        case 2: {
                            System.out.print("Username: ");
                            String username = input.next();
                            System.out.print("\nPassword: ");
                            String password = input.next();
                            airline.login(username,password);
                            break;
                        }
                        //sign up module
                        //Sign up information database me store hojaegi or wohii data user.login ke liye bhi use ki jaegiii
                        //jiska matlab hoga ke sign up hone ke baad wohii account sign in hoga
                        case 3: {
                            System.out.println("your Full Name: ");
                            String name="";
                            name += input.nextLine().replace("\n","");
                            System.out.print(
                                    "CNIC should not include any whitespaces or dashes\n" +
                                    "CNIC number: "
                            );

                            String cnic= input.next(); // a pattern should be declared
                            System.out.println("Email Address: " ); // a pattern should be declared to avoid false emails
                            String email = input.next();
                            // date of birth
                            // phone number
                            // address
                            // select a username
                            // password
                            // once user sign up krleta he ... tou ussi data ki help se hum uska login karengy
                            // or program ko extra functionality ke ke sath continue karengy..
                            //airline.signUp();
                        }
                        //End Program
                        case 4: {
                            System.out.println("\n\nBuh Byeee");
                            System.exit(0);
                        }
                    }
                }
                }

            catch (InputOutOfBound ex){
                System.out.println(ex);
            }
            catch (InputMismatchException ex){
                input.nextLine();
            }
        }while(true);
    }

    private static void showFlights(ResultSet resultSet){
        if(resultSet==null) System.out.println("No data found"); // this doesnt work this way
        else {
            try{
                System.out.println("FlightCode \tFlight Time");
                while(resultSet.next()) {
                    System.out.print(
                            resultSet.getString("flightId") +'\t'+
                            resultSet.getString("travelTo")
                    );
                }
            }
            catch (SQLException ex){
                System.out.println("Something went wrong: "+ex.getMessage());
            }
        }
    }
    private static String inputCnic(){
        String cnic;
        while (true){
            try {
                System.out.println("cnic should be separated by \"-\"\nCNIC Number: ");
                cnic = input.next();
                //4XXXX-XXXXXXX-X
                String cnicPatternStructure = "4[0-9]{4}-[0-9]{7}-[0-9]";
                Pattern cnicPattern = Pattern.compile(cnicPatternStructure);
                Matcher cnicPatternMatcher = cnicPattern.matcher(cnic);
                if(!cnicPatternMatcher.matches()) throw new InputMismatchException();
                break;
            }
            catch (InputMismatchException ex){
                System.out.print("Please Enter a Valid CNIC number! " );
            }
        }
        return cnic;
    }
    private static String inputPhone(){
        String phone;
        while (true){
            try {
                System.out.println("[0-9]{9,16}");
                phone = input.next();
                //4XXXX-XXXXXXX-X
                String phonePatternStructure = "[\\d]{6,16}";
                Pattern cnicPattern = Pattern.compile(phonePatternStructure);
                Matcher cnicPatternMatcher = cnicPattern.matcher(phone);
                System.out.println("CNIC MATCHES!! "+ cnicPatternMatcher.matches());
                if(!cnicPatternMatcher.matches()) throw new InputMismatchException();
                break;
            }
            catch (InputMismatchException ex){
                System.out.print("Please Enter a Valid CNIC number! " );
            }
        }
        return phone;
    }
    private static void seeFlights(){
        while(true) {
            try {
                // this whole implementation needs to be in the form of method because
                // it is repeated even if the user is signed in or not
                System.out.print("Enter Date of Departure (Date format: DD-MM-YYYY): ");
                Date date = new SimpleDateFormat("dd-MM-yyyy").parse(input.next());
                System.out.println("date = " +date);
                System.out.print("To: "); // To mujhe uthana chahiye flights table se
                String to =input.next();
                System.out.print("From: ");
                String from = input.next();
                System.out.print("How many passengers? ");
                int numberOfPessegers =input.nextInt(); // this number of passengers will be used for comparing with the count of booked flights in database
                System.out.print("Enter Type \n" +
                        "B for Business\n" +
                        "E for Economy\n" +
                        "Your Choice: ");
                char seatType=input.next().charAt(0);

                if(!(seatType == 'B' || seatType == 'E')) throw new InputMismatchException();
                //ab given data ke hisab se ye check karega ke kisi date ke us to-from ke liye
                //us seat type ki number of passengers ki seats available hain ya nahi
                // agar hain or nahi bhi hain tou ek option change date ka rakh jae...
                // date aggy peeche krne pr query us date ke liye chalegiii dobara or flights show karadegi

                showFlights(airline.getFlights(date,to,from,numberOfPessegers));

                //should there be array list of flight bojects , a
//                                System.exit(0)
                break;
            }
            catch (java.text.ParseException ex) {
                System.out.print("date input type mismatched\n" +
                        "Please re-enter correctly: ");
            }
            catch (InputMismatchException ex) {
                System.out.println("Please enter legal values!");
                input.nextLine();
            }
        }
    }
}
